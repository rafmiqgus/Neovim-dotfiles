-- epitech-header.nvim
-- A small Neovim plugin that inserts the classic EPITECH header, plus two helpers: :Compile and :GotoLine.
-- Ported from a Vimscript version to modern Lua APIs.

local M = {}

-- Comment maps (no shebang)
local map_no_shebang = {
  c       = { b = "/*",  m = "**",  e = "*/" },
  cpp     = { b = "//",  m = "//",  e = "//" },
  make    = { b = "##",  m = "##",  e = "##" },
  java    = { b = "//",  m = "//",  e = "//" },
  latex   = { b = "%%",  m = "%%",  e = "%%" },
  tex     = { b = "%%",  m = "%%",  e = "%%" },
  html    = { b = "<!--",m = "  --",e = "-->" },
  lisp    = { b = ";;",  m = ";;",  e = ";;" },
  css     = { b = "/*",  m = "**",  e = "*/" },
  pov     = { b = "//",  m = "//",  e = "//" },
  pascal  = { b = "{ ",  m = "   ", e = "}" },
  haskell = { b = "{-",  m = "-- ", e = "-}" },
  vim     = { b = '""',  m = '""',  e = '""' },
}

-- Comment maps (with shebang)
local map_shebang = {
  sh   = { s = "#!/usr/bin/env sh",   b = "##", m = "##", e = "##" },
  bash = { s = "#!/usr/bin/env bash", b = "##", m = "##", e = "##" },
  zsh  = { s = "#!/usr/bin/env zsh",  b = "##", m = "##", e = "##" },
  php  = { s = "#!/usr/bin/env php",  b = "/*", m = "**", e = "*/" },
  perl = { s = "#!/usr/bin/env perl", b = "##", m = "##", e = "##" },
}

local function supported(ft)
  if map_no_shebang[ft] then return 0 end
  if map_shebang[ft] then return 1 end
  return nil
end

local function goto_line_number(n)
  local maxline = vim.api.nvim_buf_line_count(0)
  local target = math.max(1, math.min(n, maxline))
  pcall(vim.api.nvim_win_set_cursor, 0, { target, 0 })
end

--- Insert EPITECH header at the top of the buffer.
function M.insert_header()
  local ft = vim.bo.filetype
  local has = supported(ft)

  if has == nil then
    vim.notify(("Epitech header: Unsupported filetype: %s"):format(ft), vim.log.levels.ERROR)
    return
  end

  local proj = vim.fn.input("Enter project name: ")
  local desc = vim.fn.input("Enter file description: ")
  local year = os.date("%Y")

  local lines = {}
  if has == 0 then
    local c = map_no_shebang[ft]
    table.insert(lines, c.b)
    table.insert(lines, c.m .. " EPITECH PROJECT, " .. year)
    table.insert(lines, c.m .. " " .. proj)
    table.insert(lines, c.m .. " File description:")
    table.insert(lines, c.m .. " " .. desc)
    table.insert(lines, c.e)
  else
    local c = map_shebang[ft]
    table.insert(lines, c.s)
    table.insert(lines, c.b)
    table.insert(lines, c.m .. " EPITECH PROJECT, " .. year)
    table.insert(lines, c.m .. " " .. proj)
    table.insert(lines, c.m .. " File description:")
    table.insert(lines, c.m .. " " .. desc)
    table.insert(lines, c.e)
  end

  vim.api.nvim_buf_set_lines(0, 0, 0, false, lines)
  goto_line_number(8)
end

--- Prompt for a build command (default: "make"), set &makeprg, then run :make.
function M.compile()
  local default = "make"
  local cmd = vim.fn.input("compile : ", default)
  if cmd == nil or cmd == "" then cmd = default end
  vim.o.makeprg = cmd
  vim.cmd("make")
end

--- Prompt for a line number and jump to it (accepts either a number or a raw Ex command).
function M.goto_line()
  local s = vim.fn.input("Goto Line : ")
  if not s or s == "" then return end
  local n = tonumber(s)
  if n then
    local maxline = vim.api.nvim_buf_line_count(0)
    local target = math.max(1, math.min(n, maxline))
    pcall(vim.api.nvim_win_set_cursor, 0, { target, 0 })
  else
    -- Fallback to executing it as a command like the Vimscript did with :exec
    pcall(vim.cmd, s)
  end
end

function M.setup(opts)
  opts = opts or {}
  -- user commands
  vim.api.nvim_create_user_command("EpiHeader", M.insert_header, {})
  vim.api.nvim_create_user_command("Compile",   M.compile,      {})
  vim.api.nvim_create_user_command("GotoLine",  M.goto_line,    {})

  -- optional default keymaps (can be disabled by setting opts.keymaps = false)
  if opts.keymaps ~= false then
    vim.keymap.set("n", "<C-c><C-h>", "<cmd>EpiHeader<CR>", { desc = "Insert Epitech header" })
    vim.keymap.set("n", "<C-c><C-c>", "<cmd>w | Compile<CR>", { desc = "Save & Compile" })
    vim.keymap.set("n", "<C-g>", "<cmd>GotoLine<CR>", { desc = "Goto line prompt" })
  end
end

return M
